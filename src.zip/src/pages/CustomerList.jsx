import React, { useEffect, useState } from 'react';
import axios from '../api/api';

const CustomerList = () => {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    const res = await axios.get('/customers');
    setCustomers(res.data);
  };

  const style = { margin: '5px', padding: '8px', fontSize: '15px', border: '1px solid #ccc' };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Customer List</h2>
      <table style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead>
          <tr style={{ background: '#ddd' }}>
            <th style={style}>Name</th>
            <th style={style}>Phone</th>
            <th style={style}>Address</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((c, idx) => (
            <tr key={idx}>
              <td style={style}>{c.name}</td>
              <td style={style}>{c.phone}</td>
              <td style={style}>{c.address}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CustomerList;
