import React, { useState, useEffect } from 'react';
import axios from '../../api/api';

const SellingPage = () => {
  const [customerId, setCustomerId] = useState('');
  const [date, setDate] = useState('');
  const [count, setCount] = useState('');
  const [rate, setRate] = useState('');
  const [wages, setWages] = useState('');
  const [total, setTotal] = useState('');
  const [customers, setCustomers] = useState([]);
  const [records, setRecords] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchCustomers();
    fetchRecords();
  }, []);

  const fetchCustomers = async () => {
    const res = await axios.get('/customers');
    setCustomers(res.data);
  };

  const fetchRecords = async () => {
    const res = await axios.get('/husk/selling');
    setRecords(res.data);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!customerId || !date || !count || !rate) {
      setError("Fill all required fields");
      return;
    }

    const c = parseInt(count) || 0;
    const r = parseFloat(rate) || 0;
    const w = parseFloat(wages) || 0;
    const totalAmount = (c * r) - w;
    setTotal(totalAmount);

    await axios.post('/husk/selling', {
      customerId,
      date,
      count: c,
      rate: r,
      wages: w,
      totalAmount
    });

    clearFields();
    fetchRecords();
  };

  const clearFields = () => {
    setCustomerId('');
    setDate('');
    setCount('');
    setRate('');
    setWages('');
    setTotal('');
    setError('');
  };

  const style = { margin: '5px', padding: '8px', fontSize: '15px' };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Husk Selling</h2>
      {error && <div style={{ color: 'red' }}>{error}</div>}

      <form onSubmit={handleSubmit} style={{ marginBottom: '20px' }}>
        <select style={style} value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
          <option value="">Select Customer</option>
          {customers.map(c => <option key={c._id} value={c._id}>{c.name}</option>)}
        </select>
        <input style={style} type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <input style={style} type="number" placeholder="Count of Loads" value={count} onChange={(e) => setCount(e.target.value)} />
        <input style={style} type="number" step="0.01" placeholder="Rate per Load" value={rate} onChange={(e) => setRate(e.target.value)} />
        <input style={style} type="number" step="0.01" placeholder="Wages" value={wages} onChange={(e) => setWages(e.target.value)} />
        <button type="submit" style={style}>Save</button>
      </form>

      {total !== '' && (
        <div style={{ marginBottom: '20px', fontWeight: 'bold' }}>
          Total Amount: ₹{total.toFixed(2)}
        </div>
      )}

      <table style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead>
          <tr style={{ background: '#ddd' }}>
            <th style={style}>Customer</th>
            <th style={style}>Date</th>
            <th style={style}>Loads</th>
            <th style={style}>Rate</th>
            <th style={style}>Wages</th>
            <th style={style}>Total</th>
          </tr>
        </thead>
        <tbody>
          {records.map((r, idx) => (
            <tr key={idx}>
              <td style={style}>{r.customerName}</td>
              <td style={style}>{r.date}</td>
              <td style={style}>{r.count}</td>
              <td style={style}>{r.rate}</td>
              <td style={style}>{r.wages}</td>
              <td style={style}>{r.totalAmount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SellingPage;
