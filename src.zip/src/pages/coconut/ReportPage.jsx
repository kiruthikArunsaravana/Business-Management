import React, { useEffect, useState } from "react";
import axios from "axios";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const CoconutReport = () => {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [buyingData, setBuyingData] = useState([]);
  const [sellingData, setSellingData] = useState([]);
  const [totalBuyingAmount, setTotalBuyingAmount] = useState(0);
  const [totalSellingAmount, setTotalSellingAmount] = useState(0);
  const [totalCoconuts, setTotalCoconuts] = useState(0);
  const [profit, setProfit] = useState(0);

  useEffect(() => {
    fetchData();
  }, [startDate, endDate]);

  const fetchData = async () => {
    try {
      const buyRes = await axios.get("http://localhost:8080/api/coconut-buying", {
        params: { startDate, endDate },
      });
      const sellRes = await axios.get("http://localhost:8080/api/coconut-selling", {
        params: { startDate, endDate },
      });

      setBuyingData(buyRes.data);
      setSellingData(sellRes.data);

      const totalBuy = buyRes.data.reduce((sum, item) => sum + item.totalAmount, 0);
      const totalSell = sellRes.data.reduce((sum, item) => sum + item.totalAmount, 0);
      const totalCount = buyRes.data.reduce((sum, item) => sum + item.countOfCoconut, 0);

      setTotalBuyingAmount(totalBuy);
      setTotalSellingAmount(totalSell);
      setTotalCoconuts(totalCount);
      setProfit(totalSell - totalBuy);
    } catch (err) {
      console.error(err);
    }
  };

  const chartData = {
    labels: ["Buying Amount", "Selling Amount", "Profit"],
    datasets: [
      {
        label: "Coconut Report",
        data: [totalBuyingAmount, totalSellingAmount, profit],
        backgroundColor: ["#f39c12", "#27ae60", "#8e44ad"],
      },
    ],
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ textAlign: "center" }}>Coconut Report</h2>

      <div style={{ display: "flex", justifyContent: "center", gap: "1rem", margin: "20px 0" }}>
        <div>
          <label>Start Date: </label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            style={{ padding: "5px" }}
          />
        </div>
        <div>
          <label>End Date: </label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            style={{ padding: "5px" }}
          />
        </div>
        <button
          onClick={fetchData}
          style={{ padding: "5px 15px", background: "#3498db", color: "white", border: "none" }}
        >
          Filter
        </button>
      </div>

      <div style={{ width: "80%", margin: "0 auto" }}>
        <Bar data={chartData} />
      </div>

      <div style={{ marginTop: "20px", textAlign: "center" }}>
        <p><strong>Total Number of Coconuts Bought:</strong> {totalCoconuts}</p>
        <p><strong>Total Amount Spent on Buying:</strong> ₹{totalBuyingAmount}</p>
        <p><strong>Total Amount Earned from Selling:</strong> ₹{totalSellingAmount}</p>
        <p><strong>Profit:</strong> ₹{profit}</p>
      </div>
    </div>
  );
};

export default CoconutReport;
