import React, { useState, useEffect } from "react";
import axios from "axios";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const TotalConsolidatedReport = () => {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const [coconut, setCoconut] = useState({ profit: 0, totalCount: 0 });
  const [husk, setHusk] = useState({ profit: 0, totalLoads: 0 });
  const [shell, setShell] = useState({ profit: 0, totalLoads: 0 });

  const totalProfit = coconut.profit + husk.profit + shell.profit;

  useEffect(() => {
    if (startDate && endDate) {
      fetchData();
    }
  }, [startDate, endDate]);

  const fetchData = async () => {
    try {
      // GET Coconut Profit & Total Coconut Bought
      const coconutRes = await axios.get("http://localhost:8080/api/coconut-summary", {
        params: { startDate, endDate }
      });
      setCoconut({
        profit: coconutRes.data.totalProfit,
        totalCount: coconutRes.data.totalCoconuts
      });

      // GET Husk Profit & Total Loads
      const huskRes = await axios.get("http://localhost:8080/api/husk-summary", {
        params: { startDate, endDate }
      });
      setHusk({
        profit: huskRes.data.totalProfit,
        totalLoads: huskRes.data.totalLoads
      });

      // GET Shell Profit & Total Loads
      const shellRes = await axios.get("http://localhost:8080/api/shell-summary", {
        params: { startDate, endDate }
      });
      setShell({
        profit: shellRes.data.totalProfit,
        totalLoads: shellRes.data.totalLoads
      });

    } catch (err) {
      console.error("Error fetching consolidated data:", err);
    }
  };

  const chartData = {
    labels: ["Coconut", "Husk", "Shell"],
    datasets: [
      {
        label: "Profit (₹)",
        data: [coconut.profit, husk.profit, shell.profit],
        backgroundColor: ["rgba(54, 162, 235, 0.6)", "rgba(255, 99, 132, 0.6)", "rgba(255, 206, 86, 0.6)"]
      }
    ]
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h2>Total Consolidated Report</h2>

      <div style={{ marginBottom: "20px" }}>
        <label>Start Date: </label>
        <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          style={{ marginRight: "10px" }}
        />
        <label>End Date: </label>
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
        />
      </div>

      <div style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "space-around",
        marginBottom: "30px"
      }}>
        <div style={cardStyle}>
          <h3>Coconut Profit</h3>
          <p style={{ fontSize: "20px", color: "green" }}>₹ {coconut.profit}</p>
        </div>
        <div style={cardStyle}>
          <h3>Husk Profit</h3>
          <p style={{ fontSize: "20px", color: "blue" }}>₹ {husk.profit}</p>
        </div>
        <div style={cardStyle}>
          <h3>Shell Profit</h3>
          <p style={{ fontSize: "20px", color: "orange" }}>₹ {shell.profit}</p>
        </div>
        <div style={cardStyle}>
          <h3>Total Coconuts Buyed</h3>
          <p style={{ fontSize: "20px", color: "purple" }}>{coconut.totalCount}</p>
        </div>
        <div style={cardStyle}>
          <h3>Total Husk Loads</h3>
          <p style={{ fontSize: "20px", color: "brown" }}>{husk.totalLoads}</p>
        </div>
        <div style={cardStyle}>
          <h3>Total Shell Loads</h3>
          <p style={{ fontSize: "20px", color: "darkred" }}>{shell.totalLoads}</p>
        </div>
        <div style={{ ...cardStyle, background: "#444", color: "white" }}>
          <h3>Grand Total Profit</h3>
          <p style={{ fontSize: "22px" }}>₹ {totalProfit}</p>
        </div>
      </div>

      <Bar data={chartData} options={{
        responsive: true,
        plugins: {
          legend: { position: "top" },
          title: { display: true, text: "Profit by Category" }
        }
      }} />
    </div>
  );
};

const cardStyle = {
  border: "1px solid #ccc",
  padding: "15px",
  borderRadius: "8px",
  minWidth: "200px",
  margin: "10px"
};

export default TotalConsolidatedReport;
