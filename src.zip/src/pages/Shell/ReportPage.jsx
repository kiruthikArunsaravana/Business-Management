import React, { useEffect, useState } from "react";
import axios from "axios";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const ShellReport = () => {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [shellData, setShellData] = useState([]);
  const [totalLoads, setTotalLoads] = useState(0);
  const [totalAmount, setTotalAmount] = useState(0);

  useEffect(() => {
    fetchData();
  }, [startDate, endDate]);

  const fetchData = async () => {
    try {
      const res = await axios.get("http://localhost:8080/api/shell-selling", {
        params: { startDate, endDate }
      });
      setShellData(res.data);

      // totals
      setTotalLoads(res.data.length);
      let amount = 0;
      res.data.forEach(item => amount += item.totalAmount);
      setTotalAmount(amount);
    } catch (err) {
      console.error("Error fetching shell data:", err);
    }
  };

  const chartData = {
    labels: shellData.map(item => item.date),
    datasets: [
      {
        label: "Amount (₹)",
        data: shellData.map(item => item.totalAmount),
        backgroundColor: "rgba(255, 159, 64, 0.6)",
      },
    ],
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h2>Shell Selling Report</h2>

      <div style={{ marginBottom: "20px" }}>
        <label>Start Date: </label>
        <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          style={{ marginRight: "10px" }}
        />
        <label>End Date: </label>
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
        />
      </div>

      <div style={{
        display: "flex",
        justifyContent: "space-around",
        marginBottom: "30px"
      }}>
        <div style={{
          border: "1px solid #ccc",
          padding: "15px",
          borderRadius: "8px",
          minWidth: "150px"
        }}>
          <h3>Number of Loads Sent</h3>
          <p style={{ fontSize: "20px", color: "green" }}>{totalLoads}</p>
        </div>
        <div style={{
          border: "1px solid #ccc",
          padding: "15px",
          borderRadius: "8px",
          minWidth: "150px"
        }}>
          <h3>Total Amount</h3>
          <p style={{ fontSize: "20px", color: "blue" }}>₹ {totalAmount}</p>
        </div>
      </div>

      <Bar data={chartData} options={{
        responsive: true,
        plugins: {
          legend: { position: "top" },
          title: { display: true, text: "Shell Selling Amount Over Time" },
        },
      }} />
    </div>
  );
};

export default ShellReport;
