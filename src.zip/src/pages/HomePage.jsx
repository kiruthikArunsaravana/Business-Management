const HomePage = () => {
  return <h2>Welcome to Coconut Business Management System</h2>;
};

export default HomePage;
