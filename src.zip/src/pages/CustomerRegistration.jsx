import React, { useState } from 'react';
import axios from '../api/api';

const CustomerRegistration = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !phone) {
      setError("Name & Phone are required");
      return;
    }

    await axios.post('/customers', { name, phone, address });
    setSuccess("Customer registered successfully!");
    setName('');
    setPhone('');
    setAddress('');
    setError('');
  };

  const style = { margin: '5px', padding: '8px', fontSize: '15px' };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Register Customer</h2>
      {error && <div style={{ color: 'red' }}>{error}</div>}
      {success && <div style={{ color: 'green' }}>{success}</div>}

      <form onSubmit={handleSubmit}>
        <input style={style} type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
        <input style={style} type="text" placeholder="Phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
        <input style={style} type="text" placeholder="Address" value={address} onChange={(e) => setAddress(e.target.value)} />
        <button type="submit" style={style}>Register</button>
      </form>
    </div>
  );
};

export default CustomerRegistration;
