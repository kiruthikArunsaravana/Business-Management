package sktraderscoconutbusiness;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoconutbusinessApplicationTests {

	@Test
	void contextLoads() {
	}

}
