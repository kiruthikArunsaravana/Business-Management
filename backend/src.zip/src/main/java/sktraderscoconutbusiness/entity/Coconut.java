package sktraderscoconutbusiness.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Coconut {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Integer quantity;

    private Double buyingPrice;
    private Double sellingPrice;

    private LocalDate date;

    // Constructors
    public Coconut() {}

    public Coconut(Integer quantity, Double buyingPrice, Double sellingPrice, LocalDate date) {
        this.quantity = quantity;
        this.buyingPrice = buyingPrice;
        this.sellingPrice = sellingPrice;
        this.date = date;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public Double getBuyingPrice() { return buyingPrice; }
    public void setBuyingPrice(Double buyingPrice) { this.buyingPrice = buyingPrice; }

    public Double getSellingPrice() { return sellingPrice; }
    public void setSellingPrice(Double sellingPrice) { this.sellingPrice = sellingPrice; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
}
