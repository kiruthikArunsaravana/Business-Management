package sktraderscoconutbusiness.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Shell {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerName;
    private Double quantityKg;
    private Double amountPerKg;
    private Double wages;

    private LocalDate date;

    public Shell() {}

    public Shell(String customerName, Double quantityKg, Double amountPerKg, Double wages, LocalDate date) {
        this.customerName = customerName;
        this.quantityKg = quantityKg;
        this.amountPerKg = amountPerKg;
        this.wages = wages;
        this.date = date;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public Double getQuantityKg() { return quantityKg; }
    public void setQuantityKg(Double quantityKg) { this.quantityKg = quantityKg; }

    public Double getAmountPerKg() { return amountPerKg; }
    public void setAmountPerKg(Double amountPerKg) { this.amountPerKg = amountPerKg; }

    public Double getWages() { return wages; }
    public void setWages(Double wages) { this.wages = wages; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
}
