package sktraderscoconutbusiness.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Husk {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerName;
    private String huskType;
    private Integer numberOfLoads;
    private Double amountPerLoad;
    private Double wages;

    private LocalDate date;

    // Constructors
    public Husk() {}

    public Husk(String customerName, String huskType, Integer numberOfLoads, Double amountPerLoad, Double wages, LocalDate date) {
        this.customerName = customerName;
        this.huskType = huskType;
        this.numberOfLoads = numberOfLoads;
        this.amountPerLoad = amountPerLoad;
        this.wages = wages;
        this.date = date;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getHuskType() { return huskType; }
    public void setHuskType(String huskType) { this.huskType = huskType; }

    public Integer getNumberOfLoads() { return numberOfLoads; }
    public void setNumberOfLoads(Integer numberOfLoads) { this.numberOfLoads = numberOfLoads; }

    public Double getAmountPerLoad() { return amountPerLoad; }
    public void setAmountPerLoad(Double amountPerLoad) { this.amountPerLoad = amountPerLoad; }

    public Double getWages() { return wages; }
    public void setWages(Double wages) { this.wages = wages; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
}
