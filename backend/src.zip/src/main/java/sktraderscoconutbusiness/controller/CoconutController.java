package sktraderscoconutbusiness.controller;

import org.springframework.web.bind.annotation.*;
import sktraderscoconutbusiness.entity.Coconut;
import sktraderscoconutbusiness.service.CoconutService;

import java.util.List;

@RestController
@RequestMapping("/api/coconuts")
@CrossOrigin(origins = "http://localhost:3000")
public class CoconutController {

    private final CoconutService coconutService;

    public CoconutController(CoconutService coconutService) {
        this.coconutService = coconutService;
    }

    @PostMapping
    public Coconut createCoconut(@RequestBody Coconut coconut) {
        return coconutService.saveCoconut(coconut);
    }

    @GetMapping
    public List<Coconut> getAllCoconuts() {
        return coconutService.getAllCoconuts();
    }
}
