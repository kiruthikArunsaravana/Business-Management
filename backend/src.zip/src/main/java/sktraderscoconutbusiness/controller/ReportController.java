package sktraderscoconutbusiness.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import sktraderscoconutbusiness.dto.ReportDTO;
import sktraderscoconutbusiness.service.ReportService;

@RestController
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping("/api/report")
    public ReportDTO getYearlyReport(@RequestParam int year) {
        return reportService.getYearlyReport(year);
    }
}
