package sktraderscoconutbusiness.controller;

import org.springframework.web.bind.annotation.*;
import sktraderscoconutbusiness.entity.Husk;
import sktraderscoconutbusiness.service.HuskService;

import java.util.List;

@RestController
@RequestMapping("/api/husks")
@CrossOrigin(origins = "http://localhost:3000")
public class HuskController {

    private final HuskService huskService;

    public HuskController(HuskService huskService) {
        this.huskService = huskService;
    }

    @PostMapping
    public Husk createHusk(@RequestBody Husk husk) {
        return huskService.saveHusk(husk);
    }

    @GetMapping
    public List<Husk> getAllHusks() {
        return huskService.getAllHusks();
    }
}
