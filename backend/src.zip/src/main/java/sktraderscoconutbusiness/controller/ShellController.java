package sktraderscoconutbusiness.controller;

import org.springframework.web.bind.annotation.*;
import sktraderscoconutbusiness.entity.Shell;
import sktraderscoconutbusiness.service.ShellService;

import java.util.List;

@RestController
@RequestMapping("/api/shells")
@CrossOrigin(origins = "http://localhost:3000")
public class ShellController {

    private final ShellService shellService;

    public ShellController(ShellService shellService) {
        this.shellService = shellService;
    }

    @PostMapping
    public Shell createShell(@RequestBody Shell shell) {
        return shellService.saveShell(shell);
    }

    @GetMapping
    public List<Shell> getAllShells() {
        return shellService.getAllShells();
    }
}
