package sktraderscoconutbusiness.dto;

public class ReportDTO {
    private Double coconutProfit;
    private Double huskProfit;
    private Double shellProfit;

    private Long coconutLoads;
    private Double huskLoads;
    private Double shellQuantity;

    public ReportDTO() {}

    public ReportDTO(Double coconutProfit, Double huskProfit, Double shellProfit,
                     Long coconutLoads, Double huskLoads, Double shellQuantity) {
        this.coconutProfit = coconutProfit;
        this.huskProfit = huskProfit;
        this.shellProfit = shellProfit;
        this.coconutLoads = coconutLoads;
        this.huskLoads = huskLoads;
        this.shellQuantity = shellQuantity;
    }

    public Double getCoconutProfit() {
        return coconutProfit;
    }

    public void setCoconutProfit(Double coconutProfit) {
        this.coconutProfit = coconutProfit;
    }

    public Double getHuskProfit() {
        return huskProfit;
    }

    public void setHuskProfit(Double huskProfit) {
        this.huskProfit = huskProfit;
    }

    public Double getShellProfit() {
        return shellProfit;
    }

    public void setShellProfit(Double shellProfit) {
        this.shellProfit = shellProfit;
    }

    public Long getCoconutLoads() {
        return coconutLoads;
    }

    public void setCoconutLoads(Long coconutLoads) {
        this.coconutLoads = coconutLoads;
    }

    public Double getHuskLoads() {
        return huskLoads;
    }

    public void setHuskLoads(Double huskLoads) {
        this.huskLoads = huskLoads;
    }

    public Double getShellQuantity() {
        return shellQuantity;
    }

    public void setShellQuantity(Double shellQuantity) {
        this.shellQuantity = shellQuantity;
    }
}
