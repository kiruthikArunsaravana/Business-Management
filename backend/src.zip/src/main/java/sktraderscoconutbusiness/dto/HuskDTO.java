package sktraderscoconutbusiness.dto;

public class HuskDTO {
    private int month;
    private int year;
    private Double totalLoad;
    private Double totalProfit;

    // Getters and setters
    public int getMonth() { return month; }
    public void setMonth(int month) { this.month = month; }

    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }

    public Double getTotalLoad() { return totalLoad; }
    public void setTotalLoad(Double totalLoad) { this.totalLoad = totalLoad; }

    public Double getTotalProfit() { return totalProfit; }
    public void setTotalProfit(Double totalProfit) { this.totalProfit = totalProfit; }
}
