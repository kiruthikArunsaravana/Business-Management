package sktraderscoconutbusiness.dto;

public class ProfitDTO {
    private double totalBuying;
    private double totalSales;
    private double totalProfit;

    public ProfitDTO() {}

    public ProfitDTO(double totalBuying, double totalSales, double totalProfit) {
        this.totalBuying = totalBuying;
        this.totalSales = totalSales;
        this.totalProfit = totalProfit;
    }

    public double getTotalBuying() {
        return totalBuying;
    }

    public void setTotalBuying(double totalBuying) {
        this.totalBuying = totalBuying;
    }

    public double getTotalSales() {
        return totalSales;
    }

    public void setTotalSales(double totalSales) {
        this.totalSales = totalSales;
    }

    public double getTotalProfit() {
        return totalProfit;
    }

    public void setTotalProfit(double totalProfit) {
        this.totalProfit = totalProfit;
    }
}
