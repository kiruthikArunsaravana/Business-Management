package sktraderscoconutbusiness.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sktraderscoconutbusiness.entity.Coconut;

@Repository
public interface CoconutRepository extends JpaRepository<Coconut, Long> {
    // You can add custom queries later
}
