package sktraderscoconutbusiness.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import sktraderscoconutbusiness.entity.Coconut;

public interface ReportRepository extends JpaRepository<Coconut, Long> {

    // Coconut
    @Query("SELECT SUM(c.quantity * (c.sellingPrice - c.buyingPrice)) FROM Coconut c WHERE YEAR(c.date) = ?1")
    Double getYearlyCoconutProfit(int year);

    @Query("SELECT SUM(c.quantity) FROM Coconut c WHERE YEAR(c.date) = ?1")
    Long getYearlyCoconutLoads(int year);


    // Husk
    @Query("SELECT SUM(h.numberOfLoads * h.amountPerLoad - h.wages) FROM Husk h WHERE YEAR(h.date) = ?1")
    Double getYearlyHuskProfit(int year);

    @Query("SELECT SUM(h.numberOfLoads) FROM Husk h WHERE YEAR(h.date) = ?1")
    Double getYearlyHuskLoads(int year);


    // Shell
    @Query("SELECT SUM(s.quantityKg * s.amountPerKg - s.wages) FROM Shell s WHERE YEAR(s.date) = ?1")
    Double getYearlyShellProfit(int year);

    @Query("SELECT SUM(s.quantityKg) FROM Shell s WHERE YEAR(s.date) = ?1")
    Double getYearlyShellQuantity(int year);
}
