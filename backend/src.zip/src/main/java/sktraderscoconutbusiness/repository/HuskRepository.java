package sktraderscoconutbusiness.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sktraderscoconutbusiness.entity.Husk;

public interface HuskRepository extends JpaRepository<Husk, Long> {
}
