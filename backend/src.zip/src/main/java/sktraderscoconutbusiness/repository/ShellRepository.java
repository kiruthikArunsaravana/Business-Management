package sktraderscoconutbusiness.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sktraderscoconutbusiness.entity.Shell;

public interface ShellRepository extends JpaRepository<Shell, Long> {
}
