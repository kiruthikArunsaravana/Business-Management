package sktraderscoconutbusiness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoconutBusinessApplication {
    public static void main(String[] args) {
        SpringApplication.run(CoconutBusinessApplication.class, args);
    }
}
