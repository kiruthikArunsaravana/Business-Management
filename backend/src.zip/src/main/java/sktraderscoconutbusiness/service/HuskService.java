package sktraderscoconutbusiness.service;

import org.springframework.stereotype.Service;
import sktraderscoconutbusiness.entity.Husk;
import sktraderscoconutbusiness.repository.HuskRepository;

import java.util.List;

@Service
public class HuskService {

    private final HuskRepository huskRepository;

    public HuskService(HuskRepository huskRepository) {
        this.huskRepository = huskRepository;
    }

    public Husk saveHusk(Husk husk) {
        return huskRepository.save(husk);
    }

    public List<Husk> getAllHusks() {
        return huskRepository.findAll();
    }
}
