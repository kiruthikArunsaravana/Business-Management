package sktraderscoconutbusiness.service;

import org.springframework.stereotype.Service;
import sktraderscoconutbusiness.dto.ReportDTO;
import sktraderscoconutbusiness.repository.ReportRepository;

@Service
public class ReportService {

    private final ReportRepository reportRepository;

    public ReportService(ReportRepository reportRepository) {
        this.reportRepository = reportRepository;
    }

    public ReportDTO getYearlyReport(int year) {
        Double coconutProfit = reportRepository.getYearlyCoconutProfit(year);
        Double huskProfit = reportRepository.getYearlyHuskProfit(year);
        Double shellProfit = reportRepository.getYearlyShellProfit(year);

        Long coconutLoads = reportRepository.getYearlyCoconutLoads(year);
        Double huskLoads = reportRepository.getYearlyHuskLoads(year);
        Double shellQuantity = reportRepository.getYearlyShellQuantity(year);

        return new ReportDTO(
                coconutProfit != null ? coconutProfit : 0.0,
                huskProfit != null ? huskProfit : 0.0,
                shellProfit != null ? shellProfit : 0.0,
                coconutLoads != null ? coconutLoads : 0L,
                huskLoads != null ? huskLoads : 0.0,
                shellQuantity != null ? shellQuantity : 0.0
        );
    }
}
