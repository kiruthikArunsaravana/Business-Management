package sktraderscoconutbusiness.service;

import org.springframework.stereotype.Service;
import sktraderscoconutbusiness.entity.Coconut;
import sktraderscoconutbusiness.repository.CoconutRepository;

import java.util.List;

@Service
public class CoconutService {

    private final CoconutRepository coconutRepository;

    public CoconutService(CoconutRepository coconutRepository) {
        this.coconutRepository = coconutRepository;
    }

    public Coconut saveCoconut(Coconut coconut) {
        return coconutRepository.save(coconut);
    }

    public List<Coconut> getAllCoconuts() {
        return coconutRepository.findAll();
    }
}
