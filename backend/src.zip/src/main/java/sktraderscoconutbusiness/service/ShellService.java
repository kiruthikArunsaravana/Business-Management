package sktraderscoconutbusiness.service;

import org.springframework.stereotype.Service;
import sktraderscoconutbusiness.entity.Shell;
import sktraderscoconutbusiness.repository.ShellRepository;

import java.util.List;

@Service
public class ShellService {

    private final ShellRepository shellRepository;

    public ShellService(ShellRepository shellRepository) {
        this.shellRepository = shellRepository;
    }

    public Shell saveShell(Shell shell) {
        return shellRepository.save(shell);
    }

    public List<Shell> getAllShells() {
        return shellRepository.findAll();
    }
}
